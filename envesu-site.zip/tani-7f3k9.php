<?php
header('Content-Type: text/plain; charset=utf-8'); header('X-Robots-Tag: noindex');
echo "PHP ", PHP_VERSION, "\nSAPI ", PHP_SAPI, "\nopenssl ", extension_loaded('openssl') ? 'var' : 'yok', "\nmbstring ", extension_loaded('mbstring') ? 'var' : 'yok', "\niconv ", function_exists('iconv') ? 'var' : 'yok', "\nfileinfo ", extension_loaded('fileinfo') ? 'var' : 'yok';
echo "\nupload_max_filesize ", ini_get('upload_max_filesize'), "\npost_max_size ", ini_get('post_max_size'), "\nmail() ", function_exists('mail') ? 'var' : 'yok', "\nsendmail_path ", ini_get('sendmail_path');
echo "\nsunucu ", gethostname(), "\nSERVER_SOFTWARE ", $_SERVER['SERVER_SOFTWARE'] ?? '', "\nHTTPS ", $_SERVER['HTTPS'] ?? '-';
$ip = @file_get_contents('https://api.ipify.org', false, stream_context_create(array('http' => array('timeout' => 6))));
echo "\ndis IP ", $ip ?: '?';
$t = microtime(true); $fp = @stream_socket_client('tcp://envesu-com.mail.protection.outlook.com:25', $en, $es, 8);
if ($fp) { stream_set_timeout($fp, 8); $b = fgets($fp, 512); fwrite($fp, "EHLO envesu.com\r\n"); $e = ''; while (($l = fgets($fp, 512)) !== false) { $e .= $l; if ($l[3] === ' ') break; } fwrite($fp, "QUIT\r\n"); fclose($fp);
  echo "\nMX:25 ACIK (", round(microtime(true) - $t, 2), " sn)\n", trim($b), "\n", (stripos($e, 'STARTTLS') !== false ? 'STARTTLS destekleniyor' : 'STARTTLS yok'); }
else echo "\nMX:25 KAPALI: $en $es";
echo "\n_form yazilabilir ", is_writable(__DIR__) ? 'evet' : 'hayir', "\n";
