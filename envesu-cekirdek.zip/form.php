<?php
/* ENVESU web sitesi — iletişim ve kariyer formu gönderimi.
   İletişim formu -> info@envesu.com, kariyer formu -> ik@envesu.com.
   Gönderim sırası: (1) _form/ayar.php'de SMTP hesabı tanımlıysa kimlik doğrulamalı SMTP,
   (2) Microsoft 365 MX sunucusuna doğrudan teslim (port 25, STARTTLS),
   (3) PHP mail(). Form içeriği sunucuda saklanmaz; günlüğe yalnız tarih/sonuç yazılır. */
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
header('X-Robots-Tag: noindex');

$CFG = array(
  'alicilar' => array('iletisim' => 'info@envesu.com', 'kariyer' => 'ik@envesu.com'),
  'gonderen' => 'web@envesu.com',
  'gonderen_ad' => 'ENVESU Web Sitesi',
  'mx' => 'envesu-com.mail.protection.outlook.com',
  'smtp' => null, // array('host'=>'smtp.office365.com','port'=>587,'user'=>'...','pass'=>'...') — yalnız _form/ayar.php içinde tanımlayın
  'cv_max' => 5 * 1024 * 1024,
);
$ayar = __DIR__ . '/_form/ayar.php';
if (is_file($ayar)) { $ek = include $ayar; if (is_array($ek)) $CFG = array_replace($CFG, $ek); }

function cevap($ok, $hata = null, $kod = 200) {
  http_response_code($kod);
  echo json_encode($ok ? array('ok' => true) : array('ok' => false, 'hata' => $hata), JSON_UNESCAPED_UNICODE);
  exit;
}
function gunluk($s) {
  $d = __DIR__ . '/_form'; if (!is_dir($d)) @mkdir($d, 0750, true);
  @file_put_contents($d . '/gunluk.txt', date('Y-m-d H:i:s') . ' ' . $s . "\n", FILE_APPEND | LOCK_EX);
}
function temiz($s, $max) {
  $s = (string)$s;
  if (function_exists('mb_substr')) $s = mb_substr($s, 0, $max, 'UTF-8'); else $s = substr($s, 0, $max);
  return trim(preg_replace('/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/u', '', $s));
}
function tekSatir($s) { return trim(preg_replace('/[\r\n\t]+/', ' ', $s)); }
function baslikKodla($s) { return '=?UTF-8?B?' . base64_encode($s) . '?='; }

if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') cevap(false, 'Geçersiz istek.', 405);
date_default_timezone_set('Europe/Istanbul');

/* Basit kötüye kullanım önlemleri */
if (!empty($_POST['web_sitesi'])) cevap(true); // bal küpü: botlara başarılı görün
if ((int)($_POST['sure'] ?? 0) < 3) cevap(false, 'Form çok hızlı gönderildi. Lütfen birkaç saniye sonra yeniden deneyin.', 429);
$ref = $_SERVER['HTTP_ORIGIN'] ?? ($_SERVER['HTTP_REFERER'] ?? '');
if ($ref !== '' && !preg_match('#^https?://(www\.)?envesu\.com(/|$)#i', $ref)) cevap(false, 'Geçersiz istek.', 403);

$ipH = substr(hash('sha256', ($_SERVER['REMOTE_ADDR'] ?? '') . '|envesu-form'), 0, 16);
$rlDir = __DIR__ . '/_form/sinir'; if (!is_dir($rlDir)) @mkdir($rlDir, 0750, true);
$rlF = $rlDir . '/' . $ipH; $now = time(); $hits = array();
if (is_file($rlF)) { foreach (explode(',', (string)@file_get_contents($rlF)) as $t) if ((int)$t > $now - 900) $hits[] = (int)$t; }
if (count($hits) >= 5) cevap(false, 'Kısa sürede çok sayıda gönderim yapıldı. Lütfen 15 dakika sonra yeniden deneyin.', 429);
$hits[] = $now; @file_put_contents($rlF, implode(',', $hits), LOCK_EX);
if (mt_rand(1, 50) === 1) { foreach ((array)glob($rlDir . '/*') as $f) if (@filemtime($f) < $now - 3600) @unlink($f); }

$tur = ($_POST['tur'] ?? '') === 'kariyer' ? 'kariyer' : 'iletisim';
$ad = tekSatir(temiz($_POST['ad'] ?? '', 120));
$ep = tekSatir(temiz($_POST['eposta'] ?? '', 160));
$msj = temiz($_POST['mesaj'] ?? '', 5000);
$alan = tekSatir(temiz($_POST[$tur === 'kariyer' ? 'alan' : 'hizmet'] ?? '', 160));
$okundu = ($_POST['aydinlatma_okundu'] ?? '') === 'Evet';

if ($ad === '' || !filter_var($ep, FILTER_VALIDATE_EMAIL)) cevap(false, 'Lütfen adınızı ve geçerli bir e-posta adresi girin.', 422);
if (!$okundu) cevap(false, 'Lütfen aydınlatma metnini okuduğunuzu işaretleyin.', 422);
if ($tur === 'iletisim' && $msj === '') cevap(false, 'Lütfen iletinizi yazın.', 422);

$ek = null;
if ($tur === 'kariyer') {
  $r1 = tekSatir(temiz($_POST['riza_aday_havuzu'] ?? '', 40));
  $r2 = tekSatir(temiz($_POST['riza_teklif'] ?? '', 40));
  $gecerli = array('Açık rıza veriyorum', 'Açık rıza vermiyorum');
  if (!in_array($r1, $gecerli, true) || !in_array($r2, $gecerli, true)) cevap(false, 'Lütfen açık rıza seçimlerinizi yapın.', 422);
  $f = $_FILES['ozgecmis'] ?? null;
  if (!$f || !is_array($f) || ($f['error'] ?? 4) !== UPLOAD_ERR_OK || !is_uploaded_file($f['tmp_name'])) cevap(false, 'Özgeçmiş dosyası yüklenemedi. Lütfen yeniden deneyin.', 422);
  if ($f['size'] > $CFG['cv_max']) cevap(false, 'Özgeçmiş dosyası en fazla 5 MB olabilir.', 422);
  $uz = strtolower(pathinfo($f['name'], PATHINFO_EXTENSION));
  $mimeler = array('pdf' => 'application/pdf', 'doc' => 'application/msword', 'docx' => 'application/vnd.openxmlformats-officedocument.wordprocessingml.document');
  if (!isset($mimeler[$uz])) cevap(false, 'Özgeçmiş PDF veya Word (.doc, .docx) biçiminde olmalıdır.', 422);
  $bas = (string)@file_get_contents($f['tmp_name'], false, null, 0, 8);
  $imza = array('pdf' => "%PDF", 'doc' => "\xD0\xCF\x11\xE0", 'docx' => "PK\x03\x04");
  if (strpos($bas, $imza[$uz]) !== 0) cevap(false, 'Özgeçmiş dosyası okunamadı. Lütfen PDF veya Word dosyası yükleyin.', 422);
  $adsiz = preg_replace('/[^A-Za-z0-9._-]+/', '-', iconv('UTF-8', 'ASCII//TRANSLIT//IGNORE', pathinfo($f['name'], PATHINFO_FILENAME)) ?: 'ozgecmis');
  $ek = array('ad' => trim($adsiz, '-') ?: 'ozgecmis', 'uz' => $uz, 'mime' => $mimeler[$uz], 'veri' => file_get_contents($f['tmp_name']));
  $ek['ad'] = substr($ek['ad'], 0, 60) . '.' . $uz;
}

$to = $CFG['alicilar'][$tur];
$tarih = date('d.m.Y H:i');
if ($tur === 'kariyer') {
  $konu = 'Kariyer başvurusu – ' . $ad . ($alan !== '' ? ' (' . $alan . ')' : '');
  $govde = "Web sitesindeki genel başvuru formundan yeni bir başvuru alındı.\n\n"
    . "Ad soyad: $ad\nE-posta: $ep\nUzmanlık alanı: " . ($alan !== '' ? $alan : '—') . "\n\nKısa tanıtım:\n" . ($msj !== '' ? $msj : '—') . "\n\n"
    . "Kariyer Başvurusu Aydınlatma Metni: Okudum ve anladım (işaretlendi)\n"
    . "Açık rıza 1 – aday havuzunda 2 yıl tutulma: $r1\n"
    . "Açık rıza 2 – ihale ve tekliflerde kullanım / yurt dışına aktarım: $r2\n\n"
    . "Özgeçmiş ektedir.\nGönderim zamanı: $tarih (TSİ)\n";
} else {
  $konu = 'Web sitesi iletişim formu – ' . $ad;
  $govde = "Web sitesindeki iletişim formundan yeni bir ileti alındı.\n\n"
    . "Ad: $ad\nE-posta: $ep\nİlgilendiği hizmet: " . ($alan !== '' ? $alan : '—') . "\n\nİleti:\n$msj\n\n"
    . "İletişim Formu Aydınlatma Metni: Okudum ve anladım (işaretlendi)\nGönderim zamanı: $tarih (TSİ)\n";
}
$DILAD = array('tr' => 'Türkçe', 'en' => 'İngilizce', 'fr' => 'Fransızca', 'de' => 'Almanca', 'es' => 'İspanyolca', 'ru' => 'Rusça', 'uz' => 'Özbekçe', 'ar' => 'Arapça');
$dil = isset($_POST['dil'], $DILAD[$_POST['dil']]) ? $_POST['dil'] : 'tr';
if ($dil !== 'tr') { $konu = '[' . strtoupper($dil) . '] ' . $konu; $govde .= "Formun doldurulduğu site dili: " . $DILAD[$dil] . " (yanıtı bu dilde vermeniz önerilir)\n"; }
$govde .= "\n—\nBu e-postayı yanıtladığınızda yanıtınız doğrudan gönderene ($ep) gider.\n";

/* MIME iletisi */
$sinir = 'envesu-' . bin2hex(random_bytes(12));
$from = $CFG['gonderen'];
$hdr = array(
  'Date: ' . date('r'),
  'From: ' . baslikKodla($CFG['gonderen_ad']) . ' <' . $from . '>',
  'To: <' . $to . '>',
  'Reply-To: ' . baslikKodla($ad) . ' <' . $ep . '>',
  'Subject: ' . baslikKodla($konu),
  'Message-ID: <' . bin2hex(random_bytes(10)) . '@envesu.com>',
  'MIME-Version: 1.0',
  'X-Mailer: envesu.com form',
);
$txt = "Content-Type: text/plain; charset=UTF-8\r\nContent-Transfer-Encoding: base64\r\n\r\n" . chunk_split(base64_encode(str_replace("\n", "\r\n", $govde)));
if ($ek) {
  $hdr[] = 'Content-Type: multipart/mixed; boundary="' . $sinir . '"';
  $body = "--$sinir\r\n$txt\r\n--$sinir\r\nContent-Type: {$ek['mime']}; name=\"{$ek['ad']}\"\r\nContent-Transfer-Encoding: base64\r\nContent-Disposition: attachment; filename=\"{$ek['ad']}\"\r\n\r\n"
    . chunk_split(base64_encode($ek['veri'])) . "\r\n--$sinir--\r\n";
} else {
  $hdr[] = 'Content-Type: text/plain; charset=UTF-8';
  $hdr[] = 'Content-Transfer-Encoding: base64';
  $body = chunk_split(base64_encode(str_replace("\n", "\r\n", $govde)));
}

function smtpGonder($host, $port, $tls, $user, $pass, $from, $to, $raw, &$err) {
  $ctx = stream_context_create(array('ssl' => array('verify_peer' => true, 'verify_peer_name' => true, 'peer_name' => $host, 'SNI_enabled' => true)));
  $fp = @stream_socket_client(($tls === 'ssl' ? 'ssl://' : 'tcp://') . $host . ':' . $port, $en, $es, 12, STREAM_CLIENT_CONNECT, $ctx);
  if (!$fp) { $err = "baglanti $host:$port $en $es"; return false; }
  stream_set_timeout($fp, 20);
  $oku = function () use ($fp) { $o = ''; while (($l = fgets($fp, 1024)) !== false) { $o .= $l; if (strlen($l) < 4 || $l[3] === ' ') break; } return $o; };
  $yaz = function ($c, $bek) use ($fp, $oku, &$err) { if ($c !== null) fwrite($fp, $c . "\r\n"); $r = $oku(); if (strpos($r, (string)$bek) !== 0) { $err = trim(($c !== null ? preg_replace('/^AUTH.*/', 'AUTH', $c) : 'banner') . ' -> ' . $r); return false; } return $r; };
  if (!$yaz(null, 220)) { fclose($fp); return false; }
  $e = $yaz('EHLO envesu.com', 250); if (!$e) { fclose($fp); return false; }
  if ($tls !== 'ssl' && stripos($e, 'STARTTLS') !== false) {
    if (!$yaz('STARTTLS', 220)) { fclose($fp); return false; }
    if (!@stream_socket_enable_crypto($fp, true, STREAM_CRYPTO_METHOD_TLSv1_2_CLIENT | (defined('STREAM_CRYPTO_METHOD_TLSv1_3_CLIENT') ? STREAM_CRYPTO_METHOD_TLSv1_3_CLIENT : 0))) { $err = 'tls'; fclose($fp); return false; }
    if (!$yaz('EHLO envesu.com', 250)) { fclose($fp); return false; }
  } elseif ($user) { $err = 'starttls yok'; fclose($fp); return false; }
  if ($user) {
    if (!$yaz('AUTH LOGIN', 334) || !$yaz(base64_encode($user), 334) || !$yaz(base64_encode($pass), 235)) { fclose($fp); return false; }
  }
  if (!$yaz('MAIL FROM:<' . $from . '>', 250) || !$yaz('RCPT TO:<' . $to . '>', 250) || !$yaz('DATA', 354)) { fclose($fp); return false; }
  $raw = preg_replace('/^\./m', '..', $raw);
  fwrite($fp, $raw . "\r\n.\r\n");
  $ok = $yaz(null, 250); @fwrite($fp, "QUIT\r\n"); fclose($fp);
  return (bool)$ok;
}

$raw = implode("\r\n", $hdr) . "\r\n\r\n" . $body;
$err = ''; $gitti = false; $yol = '';
if (is_array($CFG['smtp']) && !empty($CFG['smtp']['host'])) {
  $s = $CFG['smtp'];
  $gitti = smtpGonder($s['host'], (int)($s['port'] ?? 587), $s['tls'] ?? 'starttls', $s['user'] ?? '', $s['pass'] ?? '', $s['from'] ?? $from, $to, $raw, $err); $yol = 'smtp';
}
if (!$gitti && !empty($CFG['mx'])) { $e2 = ''; $gitti = smtpGonder($CFG['mx'], 25, 'starttls', '', '', $from, $to, $raw, $e2); $yol = 'mx'; if (!$gitti) $err .= ' | mx: ' . $e2; }
if (!$gitti) {
  $mh = array_filter($hdr, function ($x) { return stripos($x, 'To:') !== 0 && stripos($x, 'Subject:') !== 0 && stripos($x, 'Date:') !== 0; });
  $gitti = @mail($to, baslikKodla($konu), $body, implode("\r\n", $mh), '-f' . $from); $yol = 'mail';
  if (!$gitti) $err .= ' | mail() basarisiz';
}
gunluk($tur . ' ' . ($gitti ? 'GONDERILDI' : 'HATA') . ' yol=' . $yol . ($err !== '' ? ' ' . substr($err, 0, 300) : ''));
if (!$gitti) cevap(false, 'İletiniz şu anda gönderilemedi. Lütfen daha sonra yeniden deneyin ya da ' . $to . ' adresine yazın.', 502);
cevap(true);
