<?php
/* ENVESU web sitesi — sayfa yönlendirici.
   Her temiz adres (/hakkimizda-etik gibi) aynı uygulama şablonunu (app.html) sunar;
   başlık, açıklama, kanonik adres ve paylaşım etiketleri sayfaya göre sunucuda yazılır. */
$SITE = 'https://envesu.com';
$R = json_decode((string)@file_get_contents(__DIR__ . '/_routes.json'), true);
if (!is_array($R)) { http_response_code(500); exit('Yapılandırma okunamadı.'); }

function git($url, $code = 301) { header('Location: ' . $url, true, $code); exit; }

$uri  = isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : '/';
$path = rawurldecode((string)parse_url($uri, PHP_URL_PATH));
$qs   = (string)parse_url($uri, PHP_URL_QUERY);

/* Eski WordPress adresleri ve ?skills= / ?p= sorguları */
if ($path === '/' && (isset($_GET['skills']) || isset($_GET['portfolios']))) git($SITE . '/projeler');
if ($path === '/' && (isset($_GET['p']) || isset($_GET['page_id']))) git($SITE . '/');
$key = trim($path, '/');
if (strtolower($key) === 'index.php' || strtolower($key) === 'index.html') git($SITE . '/');
if (isset($R['redirects'][$key])) git($SITE . $R['redirects'][$key]);
if (strpos($key, 'portfolios/') === 0) git($SITE . '/projeler');

/* Arama motoru doğrulama dosyaları (Search Console vb.) */
if (isset($R['dogrulama']) && in_array($key, $R['dogrulama'], true)) { header('Content-Type: text/html; charset=utf-8'); echo 'google-site-verification: ' . $key; exit; }
$k = ($key === '') ? 'anasayfa' : $key;
if ($k === 'anasayfa' && $key !== '') git($SITE . '/');
/* Sonda eğik çizgi varsa tek biçime indir */
if ($key !== '' && substr($path, -1) === '/' && isset($R['pages'][$k])) git($SITE . '/' . $key . ($qs !== '' ? '?' . $qs : ''));

$tpl = (string)@file_get_contents(__DIR__ . '/app.html');
if (!isset($R['pages'][$k])) {
  http_response_code(404);
  header('Content-Type: text/html; charset=utf-8');
  header('X-Robots-Tag: noindex');
  readfile(__DIR__ . '/404.html');
  exit;
}
$p = $R['pages'][$k];
$h = function ($s) { return htmlspecialchars((string)$s, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); };
$canon = $SITE . (($p['c'] === 'anasayfa') ? '/' : '/' . $p['c']);
$img = $SITE . '/' . ($p['i'] !== '' ? $p['i'] : 'img/og-envesu.jpg');
$rep = array(
  '{{TITLE}}' => $h($p['t']),
  '{{DESC}}'  => $h($p['d']),
  '{{CANON}}' => $h($canon),
  '{{OGIMG}}' => $h($img),
  '{{OGTYPE}}' => ($k === 'anasayfa') ? 'website' : ((strpos($k, 'makale-') === 0) ? 'article' : 'website'),
);
header('Content-Type: text/html; charset=utf-8');
header('Cache-Control: no-cache');
echo strtr($tpl, $rep);
