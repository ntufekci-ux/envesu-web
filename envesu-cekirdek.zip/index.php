<?php
/* ENVESU web sitesi — sayfa yönlendirici.
   Her temiz adres (/hakkimizda-etik gibi) aynı uygulama şablonunu (app.html) sunar;
   başlık, açıklama, kanonik adres ve paylaşım etiketleri sayfaya göre sunucuda yazılır. */
$SITE = 'https://envesu.com';
$R = json_decode((string)@file_get_contents(__DIR__ . '/_routes.json'), true);
if (!is_array($R)) { http_response_code(500); exit('Yapılandırma okunamadı.'); }

function git($url, $code = 301) { header('Location: ' . $url, true, $code); exit; }

$uri  = isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : '/';
$path = rawurldecode((string)parse_url($uri, PHP_URL_PATH));
$qs   = (string)parse_url($uri, PHP_URL_QUERY);

/* Dil öneki: /en/about-us → dil "en", adres "about-us" */
$lang = 'tr';
$k0 = trim($path, '/');
if (preg_match('#^(en|fr|de|es|ru|uz|ar)(?:/(.*))?$#', $k0, $lm) && isset($R['diller'][$lm[1]])) {
  $lang = $lm[1];
  $rest = isset($lm[2]) ? $lm[2] : '';
  if (substr($path, -1) === '/') git($SITE . '/' . $lang . ($rest !== '' ? '/' . $rest : '') . ($qs !== '' ? '?' . $qs : ''));
}
function adres($l, $k) {
  global $R;
  if ($l === 'tr') return ($k === 'anasayfa') ? '/' : '/' . $k;
  $s = isset($R['diller'][$l]['slug'][$k]) ? $R['diller'][$l]['slug'][$k] : $k;
  return '/' . $l . (($k === 'anasayfa') ? '' : '/' . $s);
}

/* Eski WordPress adresleri ve ?skills= / ?p= sorguları */
if ($path === '/' && (isset($_GET['skills']) || isset($_GET['portfolios']))) git($SITE . '/projeler');
if ($path === '/' && (isset($_GET['p']) || isset($_GET['page_id']))) git($SITE . '/');
$key = trim($path, '/');
if ($lang !== 'tr') {
  $D = $R['diller'][$lang];
  if ($rest === '') $k = 'anasayfa';
  elseif (isset($D['rev'][$rest])) $k = $D['rev'][$rest];
  elseif (isset($R['pages'][$rest]) && $rest !== 'anasayfa') { if (isset($D['slug'][$rest]) && $D['slug'][$rest] !== $rest) git($SITE . adres($lang, $rest)); $k = $rest; }
  else $k = null;
  goto sayfa;
}
if (strtolower($key) === 'index.php' || strtolower($key) === 'index.html') git($SITE . '/');
if (isset($R['redirects'][$key])) git($SITE . $R['redirects'][$key]);
if (strpos($key, 'portfolios/') === 0) git($SITE . '/projeler');

/* Güvenlik iletişim dosyası (RFC 9116) */
if ($key === '.well-known/security.txt' || $key === 'security.txt') {
  header('Content-Type: text/plain; charset=utf-8');
  echo "Contact: mailto:info@envesu.com\nExpires: 2027-11-14T00:00:00.000Z\nPreferred-Languages: tr, en\nCanonical: https://envesu.com/.well-known/security.txt\n";
  exit;
}
/* Arama motoru doğrulama dosyaları (Search Console vb.) */
if (isset($R['dogrulama']) && in_array($key, $R['dogrulama'], true)) { header('Content-Type: text/html; charset=utf-8'); echo 'google-site-verification: ' . $key; exit; }
$k = ($key === '') ? 'anasayfa' : $key;
if ($k === 'anasayfa' && $key !== '') git($SITE . '/');
/* Sonda eğik çizgi varsa tek biçime indir */
if ($key !== '' && substr($path, -1) === '/' && isset($R['pages'][$k])) git($SITE . '/' . $key . ($qs !== '' ? '?' . $qs : ''));

sayfa:
$tpl = (string)@file_get_contents(__DIR__ . ($lang === 'tr' ? '/app.html' : '/app-' . $lang . '.html'));
if ($k === null || !isset($R['pages'][$k])) {
  http_response_code(404);
  header('Content-Type: text/html; charset=utf-8');
  header('X-Robots-Tag: noindex');
  readfile(__DIR__ . '/404.html');
  exit;
}
$p = $R['pages'][$k];
$h = function ($s) { return htmlspecialchars((string)$s, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); };
$canon = $SITE . adres($lang, $p['c']);
$alt = '';
foreach (array_merge(array('tr'), isset($R['diller']) ? array_keys($R['diller']) : array()) as $l) $alt .= '<link rel="alternate" hreflang="' . $l . '" href="' . $h($SITE . adres($l, $p['c'])) . '">' . "\n";
$alt .= '<link rel="alternate" hreflang="x-default" href="' . $h($SITE . adres('tr', $p['c'])) . '">' . "\n";
$t = $p['t']; $d = $p['d'];
if ($lang !== 'tr' && isset($p['L'][$lang])) { $t = $p['L'][$lang][0]; $d = $p['L'][$lang][1]; }
$img = $SITE . '/' . ($p['i'] !== '' ? $p['i'] : 'img/og-envesu.jpg');
/* Sayfanın üst görseli önceden yüklenir (dar ekranda 1200 px'lik sürüm) */
$onyukle = '';
if (!empty($p['h']) && preg_match('#^img/([A-Za-z0-9_-]+)\.jpg$#', $p['h'], $hm)) {
  if (!empty($R['mob']) && in_array($hm[1], $R['mob'], true))
    $onyukle = '<link rel="preload" as="image" href="/img/m/' . $hm[1] . '.jpg" media="(max-width:760px)" fetchpriority="high">' . "\n" . '<link rel="preload" as="image" href="/img/' . $hm[1] . '.jpg" media="(min-width:761px)" fetchpriority="high">' . "\n";
  else
    $onyukle = '<link rel="preload" as="image" href="/img/' . $hm[1] . '.jpg" fetchpriority="high">' . "\n";
}
$rep = array(
  '{{TITLE}}' => $h($t),
  '{{DESC}}'  => $h($d),
  '{{HREFLANG}}' => $alt,
  '{{CANON}}' => $h($canon),
  '{{OGIMG}}' => $h($img),
  '{{PRELOAD}}' => $onyukle,
  '{{OGTYPE}}' => ($k === 'anasayfa') ? 'website' : ((strpos($k, 'makale-') === 0) ? 'article' : 'website'),
);
header('Content-Type: text/html; charset=utf-8');
header('Cache-Control: no-cache');
echo strtr($tpl, $rep);
